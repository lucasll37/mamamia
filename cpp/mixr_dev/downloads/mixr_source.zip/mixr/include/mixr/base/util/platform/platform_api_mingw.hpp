
#ifndef __mixr_base_util_platform_api_mingw_H__
#define __mixr_base_util_platform_api_mingw_H__

#include <winsock2.h>

#endif
