
UML diagram drawn with the open source UMLet v14.2 tool.

Available here: www.umlet.com

