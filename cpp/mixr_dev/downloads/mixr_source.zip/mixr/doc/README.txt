
The .cfg files are configuration files for doxygen.

They haven't been updated in quite a while... probably out of date.


-------------------------------------------------------

Two doxygen configuration files can be found in the
directory. doxygen can be downloaded from:

www.doxygen.org

After installation, issue the following command at 
the prompt:

doxygen doxygenNoGraphics.cfg

If you would like to have doxygen produce collaboration
diagrams and header dependency graphs you need to have
GraphViz installed as well. GraphViz can be downloaded
from:

www.graphviz.org

After installation, issue the following command at 
the prompt:

doxygen doxygenGraphics.cfg

An html directory will be created. Open the index file
to view.

-------------------------------------------------------
