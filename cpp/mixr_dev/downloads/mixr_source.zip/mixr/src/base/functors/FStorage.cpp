
#include "mixr/base/functors/FStorage.hpp"

namespace mixr {
namespace base {

IMPLEMENT_SUBCLASS(FStorage, "FStorage")
EMPTY_SLOTTABLE(FStorage)
EMPTY_CONSTRUCTOR(FStorage)
EMPTY_COPYDATA(FStorage)
EMPTY_DELETEDATA(FStorage)

}
}
