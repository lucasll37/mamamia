
Simple ground mapping radar test
 -- just processing terrain effect at this time

Edit scenario.epp to change the path to the terrain data (e.g., linux vs windows)

