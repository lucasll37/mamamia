mainUbf1
--------

A general purpose program to demonstrate UBF capabilities

To run:

>> mainUbf1 -f filename.edl

Example Files
-------------

 - "test00.edl" -> Simple player flying straight

 - "test10.edl" ->

 - "test20.edl" ->

