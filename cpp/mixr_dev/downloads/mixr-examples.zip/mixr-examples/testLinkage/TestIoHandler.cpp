
#include "TestIoHandler.hpp"

IMPLEMENT_SUBCLASS(TestIoHandler, "TestIoHandler")
EMPTY_SLOTTABLE(TestIoHandler)
EMPTY_CONSTRUCTOR(TestIoHandler)
EMPTY_COPYDATA(TestIoHandler)
EMPTY_DELETEDATA(TestIoHandler)

