
1) Terrain elevation viewer with options to added effects (in development)

2) Edit test.d to ...
  a) change the path to the terrain data (e.g., linux vs windows)
  b) change option flags (shadows, aac, etc)


