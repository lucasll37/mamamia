

To run:
  mainCockpit -f test1.edl

keyboard controls:

   'r' or 'R'   -- Reset simulation
   'f' or 'F'   -- Toggle simulation freeze
   'l' or 'L'   -- Launch Missile
   'a' or 'A'   -- A/A mode (TWS)
   'g' or 'G'   -- A/G mode (GMTI)
   's' or 'S'   -- Target step
   'i' or 'I'   -- Increase Range
   'd' or 'D'   -- Decrease Range
   '+'          -- Ownship step (to next local air vehicle)
   esc          -- Exit
