
// -----------------------------------------------------------------------------
// Test functions for the LFI table classes (Table, Table1, Table2, ...)
// -----------------------------------------------------------------------------

There are several programs in this project.  

    test1.cpp -- tests Table1 using "test1.edl"
    
    test2.cpp -- tests Table2 using "test2.edl"
    
    test3.cpp -- tests Table3 using "test3a.edl" (small) and "test3.edl" (large)
    
    test4.cpp -- tests Table4 using "test4.edl"
