//-----------------------------------------------------------------------------
// Test reading data recorder streams and binary files
//
//  -- Reads either a binary data file or network stream;
//     see "./configs/test.epp"
//
//  -- Default uses 'mainy1' to generate the data;
//     default reads from "../mainy1/zFileWriter.ebd"
//     see "../mainy1/configs/dataRecorder.epp"
//
//-----------------------------------------------------------------------------

