
#ifndef __events_H__
#define __events_H__

#include "mixr/base/Component.hpp"

// synonym for convenience
const int USER_EVENT_ON_ENTRY = ::mixr::base::Component::USER_EVENTS + 1;

#endif
