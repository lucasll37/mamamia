
'testGraphics' -- Used to test 'basic' and 'basicGL' classes

   test.d  -- default
   test2.d -- double page
   
   
controls:

   'n' or 'N'   -- Next display page
   'p' or 'P'   -- Previous display page
   esc  -- Exit
   
Pick/Select test:
    Selected items with mouse and single, left mouse click
    Selected item will flash
    Use the lower, left corner to text strings
