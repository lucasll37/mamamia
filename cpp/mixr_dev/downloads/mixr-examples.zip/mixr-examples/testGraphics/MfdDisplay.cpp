
#include "MfdDisplay.hpp"

using namespace mixr;

IMPLEMENT_EMPTY_SLOTTABLE_SUBCLASS(MfdDisplay, "MfdDisplay")

EMPTY_COPYDATA(MfdDisplay)
EMPTY_DELETEDATA(MfdDisplay)

MfdDisplay::MfdDisplay()
{
   STANDARD_CONSTRUCTOR()
}
