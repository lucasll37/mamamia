#include "UpdateProperty.h"

using namespace gsc;

